EMAIL_USE_TLS = True
EMAIL_HOST = 'smpt.gmail.com'
EMAIL_HOST_USER = '4vv19cs116@vvce.ac.in'
EMAIL_HOST_PASSWORD = 'vvce@123'
EMAIL_PORT = 587
